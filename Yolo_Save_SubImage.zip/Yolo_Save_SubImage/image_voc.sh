

./darknet detector test ./cfg/voc.data ./cfg/yolo-voc.cfg ./yolo-voc.weights dog.jpg -i 0 -thresh 0.2



